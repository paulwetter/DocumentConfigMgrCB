﻿param(
[parameter(Mandatory=$false)]
$SiteServer,
[parameter(Mandatory=$false)]
$TaskSequence
)

function Load-Form {
    $Form.Controls.Add($DGVPackageRef)
    $Form.Controls.Add($DGVPackageDP)
    $Form.Controls.Add($GBPackageRef)
    $Form.Controls.Add($GBPackageDP)
	$Form.Add_Shown({$Form.Activate()})
    $Form.Add_Shown({Get-TSReferences})
	[void]$Form.ShowDialog()
}

function Get-CMSiteCode {
    $CMSiteCode = Get-WmiObject -Namespace "root\SMS" -Class SMS_ProviderLocation -ComputerName $SiteServer | Select-Object -ExpandProperty SiteCode
    return $CMSiteCode
}

function Get-TSReferences {
    $SiteCode = Get-CMSiteCode
    $TSPackageID = Get-WmiObject -Namespace "root\SMS\site_$($SiteCode)" -Class SMS_TaskSequencePackage -ComputerName $SiteServer -Filter "Name like '$($TaskSequence)'" | Select-Object -ExpandProperty PackageID
    $TSReferences = Get-WmiObject -Namespace "root\SMS\site_$($SiteCode)" -Class SMS_TaskSequencePackageReference -ComputerName $SiteServer -Filter "PackageID like '$($TSPackageID)'"
    $TSReferencesSorted = $TSReferences | Sort-Object -Property ObjectName
    $TSReferencesSorted | ForEach-Object {
        switch ($_.ObjectType) {
            0 { $CurrentPackageType = "Package" }
            3 { $CurrentPackageType = "Driver Package" }
            257 { $CurrentPackageType = "OS Image Package" }
            258 { $CurrentPackageType = "Boot Image" }
            259 { $CurrentPackageType = "OS Install Package" }
            512 { $CurrentPackageType = "Application" }
        }
        $DGVPackageRef.Rows.Add($_.ObjectName, $_.NumberSuccess, $_.RefPackageID, $CurrentPackageType)
    }
}

function Get-PackageDPDetails {
    param(
    [parameter(Mandatory=$true)]
    [string]$Value
    )
    if ($DGVPackageDP.Rows.Count -ge 1) {
        $DGVPackageDP.Rows.Clear()
        $DGVPackageDP.Refresh()
    }
    $SiteCode = Get-CMSiteCode
    $DPs = Get-WmiObject -Namespace "root\SMS\site_$($SiteCode)" -Class SMS_DistributionDPStatus -ComputerName $SiteServer -Filter "PackageID like '$($Value)'" | Select-Object NALPath, MessageState
    $DPs | ForEach-Object {
        $TrimmedServerNALPath = ($_.NALPath).Split(']')[0].TrimStart('["Display=')
        $CurrentServerNALPath = $TrimmedServerNALPath.SubString(0,$TrimmedServerNALPath.Length-2)
        switch ($_.MessageState) {
            1 { $CurrentMessageState = "Success" }
            2 { $CurrentMessageState = "In Progress" }
            3 { $CurrentMessageState = "Error" }
        }
        $DGVPackageDP.Rows.Add($CurrentServerNALPath, $CurrentMessageState)
    }
}

# Assemblies
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

# Form
$Form = New-Object System.Windows.Forms.Form    
$Form.Size = New-Object System.Drawing.Size(850,605)  
$Form.MinimumSize = New-Object System.Drawing.Size(850,605)
$Form.MaximumSize = New-Object System.Drawing.Size(850,605)
$Form.SizeGripStyle = "Hide"
$Form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($PSHome + "\powershell.exe")
$Form.Text = "Task Sequence Package References 1.0"
$Form.ControlBox = $true
$Form.TopMost = $true

# DataGriView
$DGVPackageRef = New-Object System.Windows.Forms.DataGridView
$DGVPackageRef.Location = New-Object System.Drawing.Size(20,30)
$DGVPackageRef.Size = New-Object System.Drawing.Size(800,270)
$DGVPackageRef.ColumnCount = 4
$DGVPackageRef.ColumnHeadersVisible = $true
$DGVPackageRef.Columns[0].Name = "Package"
$DGVPackageRef.Columns[0].AutoSizeMode = "Fill"
$DGVPackageRef.Columns[1].Name = "Success"
$DGVPackageRef.Columns[1].Width = 60
$DGVPackageRef.Columns[2].Name = "Package ID"
$DGVPackageRef.Columns[2].Width = 70
$DGVPackageRef.Columns[3].Name = "Package Type"
$DGVPackageRef.Columns[3].Width = 110
$DGVPackageRef.AllowUserToAddRows = $false
$DGVPackageRef.AllowUserToDeleteRows = $false
$DGVPackageRef.ReadOnly = $True
$DGVPackageRef.ColumnHeadersHeightSizeMode = "DisableResizing"
$DGVPackageRef.RowHeadersWidthSizeMode = "DisableResizing"
$DGVPackageRef.Add_CellContentClick({
    if ($DGVPackageRef.CurrentCellAddress.X -eq 0) {
        $SelectedPackageID = $DGVPackageRef.Rows[$DGVPackageRef.SelectedCells[0].RowIndex].Cells[2].Value
        Get-PackageDPDetails -Value $SelectedPackageID
    }
})
$DGVPackageDP = New-Object System.Windows.Forms.DataGridView
$DGVPackageDP.Location = New-Object System.Drawing.Size(20,335)
$DGVPackageDP.Size = New-Object System.Drawing.Size(800,220)
$DGVPackageDP.ColumnCount = 2
$DGVPackageDP.ColumnHeadersVisible = $true
$DGVPackageDP.Columns[0].Name = "Distribution Point"
$DGVPackageDP.Columns[0].AutoSizeMode = "Fill"
$DGVPackageDP.Columns[1].Name = "Distribution Status"
$DGVPackageDP.Columns[1].Width = 100
$DGVPackageDP.AllowUserToAddRows = $false
$DGVPackageDP.AllowUserToDeleteRows = $false
$DGVPackageDP.ReadOnly = $True
$DGVPackageDP.ColumnHeadersHeightSizeMode = "DisableResizing"
$DGVPackageDP.RowHeadersWidthSizeMode = "DisableResizing"

# Group Boxes
$GBPackageRef = New-Object System.Windows.Forms.GroupBox
$GBPackageRef.Location = New-Object System.Drawing.Size(10,10) 
$GBPackageRef.Size = New-Object System.Drawing.Size(820,300) 
$GBPackageRef.Text = "Packages referenced in the task sequence"
$GBPackageRef.Name = "PackageRef"
$GBPackageDP = New-Object System.Windows.Forms.GroupBox
$GBPackageDP.Location = New-Object System.Drawing.Size(10,315) 
$GBPackageDP.Size = New-Object System.Drawing.Size(820,250) 
$GBPackageDP.Text = "Distribution Status for selected package"
$GBPackageDP.Name = "PackageDP"

# Load Form
Load-Form